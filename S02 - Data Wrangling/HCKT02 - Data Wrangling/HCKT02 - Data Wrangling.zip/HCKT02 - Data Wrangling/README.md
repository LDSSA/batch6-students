# LDSSA Hackathon #2 - Data Wrangling

All you need to know is in this [link](https://docs.google.com/document/d/1RtRzVYs5BAhh3BUDYUcdpC9jbxQHsNOz6dNR6P9N8VI/edit#heading=h.ejeq9rg4kyaz) 
